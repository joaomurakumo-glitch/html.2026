﻿using Microsoft.Data.SqlClient;
using System.Data;
using System.Text;

namespace Db_agenda
{
    public class Banco_de_dados
    {
        private string serverName = string .Empty;
        private string DatabaseName = string .Empty;
        private bool integratedSecurity = false;
        private bool encrypt = false;
        private SqlConnection? connection = null;

        public Banco_de_dados(string serverName, string DatabaseName, bool integratedSecurity, bool encrypt) 
        { 
           this.serverName = serverName;
           this.DatabaseName = DatabaseName;
           this.integratedSecurity = integratedSecurity;
           this.encrypt = encrypt;
        }

        private string GetConnectionString() 
        {
            StringBuilder sb = new StringBuilder();

            sb.Append($"Data Source={serverName};");
            sb.Append($"Initial Catalog={DatabaseName};");
            sb.Append($"Integrated Security={integratedSecurity};");
            sb.Append($"Encrypt={encrypt};");

            return sb.ToString();
        }

        public bool Connectar() 
        {
            if (connection == null) 
            { 
                string connStr = GetConnectionString();
                connection = new SqlConnection(connStr);
                
            }
            try 
            {
                if (connection.State != ConnectionState.Open)
                    connection.Open();
            }
            catch(Exception e) 
            
            {
            
                throw new Exception(e.Message);
            }
            return GetConectado();
        }

        public bool GetConectado()  
        { 
            return connection == null ? false : connection.State == ConnectionState.Open;
        
        }

        public void Desconectar() 
        {
            if (connection == null)
                return;

            if (connection.State == ConnectionState.Open)
                connection.Close();

            connection.Dispose();
            connection = null;
        
        }

        public SqlConnection? GetConnection() 
        {
            return connection;


        }

        /*
    
        Data Source=SNCHLAB01147793\SQLEXPRESS;
        Initial Catalog=Db_agenda;
        Integrated Security=True;
        Encrypt=False;

        */

    }
}
