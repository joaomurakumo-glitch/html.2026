using Microsoft.Data.SqlClient;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Db_agenda
{
    public partial class Form1 : Form
    {
        private List<Pais>? Listapaises = null;
        public Form1()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Banco_de_dados bd = new Banco_de_dados("SNCHLABC658484\\SQLEXPRESS", "Db_agenda", true, false);

            try
            {

                bd.Connectar();

                if (bd.GetConectado()) 
                {
                    Listapaises = new List<Pais>();

                    string query = "SELECT Codigo, Nome, Abreviatura FROM Tb_pais";

                    using (SqlCommand cmd = new SqlCommand(query, bd.GetConnection())) 
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader()) 
                        {
                            while (reader.Read()) 
                            { 
                                Pais pais = new Pais();

                                pais.Codigo = Convert.ToInt32(reader["Codigo"]);
                                pais.Nome = reader["Nome"].ToString()!;
                                pais.Abreviatura = reader["Abreviatura"].ToString();

                                Listapaises.Add(pais);
                            
                            }
                        
                        
                        }
                    
                    
                    }




                }
                dataGridView1.DataSource = Listapaises;
                //MessageBox.Show("Banco de dados conectado com sucesso");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally 
            { 
              bd.Desconectar();
            }




        }

       
    }
}
