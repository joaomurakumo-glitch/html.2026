﻿using System.Data;
using System.Text;
using Microsoft.Data.SqlClient;

namespace WinAgenda
{
    public class BancoDeDados
    {
        private string serverName = string.Empty;
        private string databaseName = string.Empty;
        private bool integratedSecurity = false;
        private bool encrypt = false;
        private SqlConnection? connection = null;

        public BancoDeDados(string serverName, string databaseName,
            bool integratedSecurity, bool encrypt)
        {
            this.serverName = serverName;
            this.databaseName = databaseName;
            this.integratedSecurity = integratedSecurity;
            this.encrypt = encrypt;
        }

        private string GetConnectionString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append($"Data Source={serverName};");
            sb.Append($"Initial Catalog={databaseName};");
            sb.Append($"Integrated Security={integratedSecurity};");
            sb.Append($"Encrypt={encrypt};");

            return sb.ToString();
        }

        public bool Conectar()
        {
            if (connection == null)
            { 
                string connStr = GetConnectionString();
                connection = new SqlConnection(connStr);
            }

            try
            {
                if (connection.State != ConnectionState.Open) 
                    connection.Open();
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }

            return GetConectado();
        }

        public bool GetConectado()
        {
            return connection == null ? false : connection.State == ConnectionState.Open;
        }

        public void Desconectar()
        {
            if (connection == null)
                return;

            if (connection.State == ConnectionState.Open)
                connection.Close();

            connection.Dispose();
            connection = null;
        }

        public SqlConnection? GetConnection()
        {
            return connection;
        }

    }
}
