using Microsoft.Data.SqlClient;

namespace WinAgenda
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void paisesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (FormPaisGrid frm = new FormPaisGrid())
            {
                frm.ShowDialog();
                frm.Dispose();
            }
        }
    }
}
