﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace WinAgenda
{
    public partial class FormPaisGrid : Form
    {
        private List<Pais>? listaDePaises = null;

        public FormPaisGrid()
        {
            InitializeComponent();
            ConsultarPaises();
        }

        private void ConsultarPaises()
        {
            BancoDeDados bd = new BancoDeDados(
                                    "SNCHLABC136740\\SQLEXPRESS",
                                    "Db_Agenda",
                                    true,
                                    false
                                  );

            try
            {
                bd.Conectar();

                if (bd.GetConectado())
                {
                    listaDePaises = new List<Pais>();

                    string query = "SELECT Codigo, Nome, Abreviatura FROM TB_Pais";

                    using (SqlCommand cmd = new SqlCommand(query, bd.GetConnection()))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Pais pais = new Pais();

                                pais.Codigo = Convert.ToInt32(reader["Codigo"]);
                                pais.Nome = reader["Nome"].ToString()!;
                                pais.Abreviatura = reader["Abreviatura"].ToString()!;

                                listaDePaises.Add(pais);
                            }
                        }
                    }

                    dataGridView1.DataSource = listaDePaises;
                }

                //MessageBox.Show("Banco de dados concectado com sucesso.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                bd.Desconectar();
            }
        }
    }
}
