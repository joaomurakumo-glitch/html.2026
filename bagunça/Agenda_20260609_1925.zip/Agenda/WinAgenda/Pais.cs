﻿namespace WinAgenda
{
    public class Pais
    {
        public int Codigo { get; set; }
        public string Nome { get; set; } = string.Empty;
        public string? Abreviatura { get; set; } = null;
    }
}
