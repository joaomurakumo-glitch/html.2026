using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace ParOuImpar
{
    public partial class Form1 : Form
    {
        // ─── Estado do jogo ───────────────────────────────────────────
        private int pontoJogador = 0;
        private int pontoComputador = 0;
        private int empates = 0;
        private const int PONTOS_PARA_VENCER = 5;
        private string escolhaJogador = "";   // "PAR" ou "IMPAR"
        private int numeroJogador = 0;

        private List<HistoricoRodada> historico = new List<HistoricoRodada>();
        private Random rnd = new Random();

        // ─── Painéis (telas) ──────────────────────────────────────────
        private Panel pnlInicio;
        private Panel pnlJogo;
        private Panel pnlResultado;
        private Panel pnlHistorico;
        private Panel pnlFinal;

        // ─── Controles do placar (pnlJogo) ────────────────────────────
        private Label lblPlacarJogador, lblPlacarEmpate, lblPlacarComp;

        // ─── Controles de resultado ───────────────────────────────────
        private Label lblResJogador, lblResEmpate, lblResComp;
        private Label lblResEscolhaJogador, lblResNumJogador;
        private Label lblResEscolhaComp, lblResNumComp;
        private Label lblResSoma, lblResMensagem;
        private PictureBox picResJogador, picResComp, picResTrofeu;

        // ─── Controles de final ───────────────────────────────────────
        private Label lblFinalMensagem, lblFinalPlacar;
        private PictureBox picFinalIcone;

        // ─────────────────────────────────────────────────────────────
        public Form1()
        {
            InitializeComponent();
            this.Text = "Par ou Ímpar";
            this.Size = new Size(480, 620);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 244, 255);
            this.Font = new Font("Segoe UI", 9f);

            CriarTelaInicio();
            CriarTelaJogo();
            CriarTelaResultado();
            CriarTelaHistorico();
            CriarTelaFinal();

            MostrarTela(pnlInicio);
        }

        // ════════════════════════════════════════════════════════════
        //  TELA 1 – INÍCIO
        // ════════════════════════════════════════════════════════════
        private void CriarTelaInicio()
        {
            pnlInicio = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(240, 244, 255) };
            this.Controls.Add(pnlInicio);

            // Banner título
            var pnlBanner = new Panel
            {
                Size = new Size(400, 120),
                Location = new Point(40, 40),
                BackColor = Color.FromArgb(20, 30, 80),
            };
            ArredondarPanel(pnlBanner, 20);
            pnlInicio.Controls.Add(pnlBanner);

            var lblTitulo = new Label
            {
                Text = "PAR OU ÍMPAR",
                Font = new Font("Segoe UI Black", 26f, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = false,
                Size = new Size(400, 80),
                Location = new Point(0, 20),
                TextAlign = ContentAlignment.MiddleCenter
            };
            // "ÍMPAR" em amarelo/laranja – usando rich text via Paint
            pnlBanner.Controls.Add(lblTitulo);
            lblTitulo.Paint += (s, e) =>
            {
                e.Graphics.Clear(Color.FromArgb(20, 30, 80));
                using var fNormal = new Font("Segoe UI Black", 26f, FontStyle.Bold);
                using var fAmarel = new Font("Segoe UI Black", 26f, FontStyle.Bold);
                string p1 = "PAR OU ";
                string p2 = "ÍMPAR";
                SizeF s1 = e.Graphics.MeasureString(p1, fNormal);
                SizeF s2 = e.Graphics.MeasureString(p2, fAmarel);
                float totalW = s1.Width + s2.Width - 8;
                float x = (lblTitulo.Width - totalW) / 2f;
                float y = (lblTitulo.Height - s1.Height) / 2f;
                e.Graphics.DrawString(p1, fNormal, Brushes.White, x, y);
                e.Graphics.DrawString(p2, fAmarel, new SolidBrush(Color.FromArgb(255, 180, 0)), x + s1.Width - 8, y);
            };

            // Ícone mãos (emoji)
            var lblMaos = new Label
            {
                Text = "🤚  ✊",
                Font = new Font("Segoe UI Emoji", 36f),
                AutoSize = false,
                Size = new Size(400, 80),
                Location = new Point(40, 170),
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.Transparent
            };
            pnlInicio.Controls.Add(lblMaos);

            // Subtítulo
            var lblSub = new Label
            {
                Text = "JOGADOR CONTRA COMPUTADOR",
                Font = new Font("Segoe UI", 11f, FontStyle.Bold),
                ForeColor = Color.FromArgb(40, 50, 100),
                AutoSize = false,
                Size = new Size(400, 30),
                Location = new Point(40, 260),
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.Transparent
            };
            pnlInicio.Controls.Add(lblSub);

            // Botão Iniciar Jogo
            var btnIniciar = CriarBotao("▶  INICIAR JOGO", Color.FromArgb(34, 160, 74), 200, 50);
            btnIniciar.Location = new Point(140, 320);
            btnIniciar.Click += (s, e) => MostrarTela(pnlJogo);
            pnlInicio.Controls.Add(btnIniciar);

            // Caixa "Como funciona"
            var pnlComo = new Panel
            {
                Size = new Size(400, 160),
                Location = new Point(40, 400),
                BackColor = Color.FromArgb(230, 240, 255),
            };
            ArredondarPanel(pnlComo, 14);
            pnlInicio.Controls.Add(pnlComo);

            var lblComoTitulo = new Label
            {
                Text = "💡  COMO FUNCIONA",
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = Color.FromArgb(0, 100, 200),
                AutoSize = false,
                Size = new Size(380, 28),
                Location = new Point(10, 10),
                BackColor = Color.Transparent
            };
            pnlComo.Controls.Add(lblComoTitulo);

            string regras =
                "• Você escolhe Par ou Ímpar e um número (1 a 5).\n" +
                "• O computador escolhe um número (1 a 5).\n" +
                "• Somamos os números.\n" +
                "• Se a soma for Par e você escolheu Par, você ganha!\n" +
                "• Se a soma for Ímpar e você escolheu Ímpar, você ganha!\n" +
                "• Vence quem chegar a 5 pontos primeiro!";

            var lblRegras = new Label
            {
                Text = regras,
                Font = new Font("Segoe UI", 8.5f),
                ForeColor = Color.FromArgb(40, 60, 120),
                AutoSize = false,
                Size = new Size(380, 120),
                Location = new Point(10, 38),
                BackColor = Color.Transparent
            };
            pnlComo.Controls.Add(lblRegras);
        }

        // ════════════════════════════════════════════════════════════
        //  TELA 2 – JOGO
        // ════════════════════════════════════════════════════════════
        private void CriarTelaJogo()
        {
            pnlJogo = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(240, 244, 255), Visible = false };
            this.Controls.Add(pnlJogo);

            // ── Placar ──────────────────────────────────────────────
            var pnlPlacar = new Panel
            {
                Size = new Size(400, 90),
                Location = new Point(40, 20),
                BackColor = Color.FromArgb(20, 30, 80)
            };
            ArredondarPanel(pnlPlacar, 16);
            pnlJogo.Controls.Add(pnlPlacar);

            var lblPlacarTit = new Label
            {
                Text = "PLACAR",
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.FromArgb(160, 180, 220),
                AutoSize = false, Size = new Size(400, 22),
                Location = new Point(0, 8), TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.Transparent
            };
            pnlPlacar.Controls.Add(lblPlacarTit);

            // 3 colunas
            int[] xs = { 20, 150, 280 };
            string[] titulos = { "JOGADOR", "EMPATES", "COMPUTADOR" };
            Color[] cores = { Color.FromArgb(0, 100, 220), Color.FromArgb(80, 80, 80), Color.FromArgb(230, 100, 0) };
            Label[] labelsPlacar = new Label[3];

            for (int i = 0; i < 3; i++)
            {
                var pnlCol = new Panel
                {
                    Size = new Size(110, 55),
                    Location = new Point(xs[i], 28),
                    BackColor = cores[i]
                };
                ArredondarPanel(pnlCol, 10);
                pnlPlacar.Controls.Add(pnlCol);

                var lblTit = new Label
                {
                    Text = titulos[i],
                    Font = new Font("Segoe UI", 7f, FontStyle.Bold),
                    ForeColor = Color.White,
                    AutoSize = false, Size = new Size(110, 18),
                    Location = new Point(0, 4), TextAlign = ContentAlignment.MiddleCenter,
                    BackColor = Color.Transparent
                };
                pnlCol.Controls.Add(lblTit);

                var lblNum = new Label
                {
                    Text = "0",
                    Font = new Font("Segoe UI Black", 20f, FontStyle.Bold),
                    ForeColor = Color.White,
                    AutoSize = false, Size = new Size(110, 30),
                    Location = new Point(0, 20), TextAlign = ContentAlignment.MiddleCenter,
                    BackColor = Color.Transparent
                };
                pnlCol.Controls.Add(lblNum);
                labelsPlacar[i] = lblNum;
            }
            lblPlacarJogador = labelsPlacar[0];
            lblPlacarEmpate = labelsPlacar[1];
            lblPlacarComp = labelsPlacar[2];

            // ── Escolha PAR / ÍMPAR ─────────────────────────────────
            var lblEscolhaTit = new Label
            {
                Text = "ESCOLHA PAR OU ÍMPAR",
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = Color.FromArgb(20, 30, 80),
                AutoSize = false, Size = new Size(400, 28),
                Location = new Point(40, 130), TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.Transparent
            };
            pnlJogo.Controls.Add(lblEscolhaTit);

            var btnPar = CriarBotao("🖐  PAR", Color.FromArgb(0, 100, 220), 180, 55);
            btnPar.Location = new Point(40, 165);
            var btnImpar = CriarBotao("✊  ÍMPAR", Color.FromArgb(230, 100, 0), 180, 55);
            btnImpar.Location = new Point(240, 165);

            Button btnParImparSel = null;
            btnPar.Click += (s, e) => { SelecionarParImpar("PAR", btnPar, btnImpar); };
            btnImpar.Click += (s, e) => { SelecionarParImpar("IMPAR", btnPar, btnImpar); };
            pnlJogo.Controls.Add(btnPar);
            pnlJogo.Controls.Add(btnImpar);

            // ── Escolha número ──────────────────────────────────────
            var lblNumTit = new Label
            {
                Text = "ESCOLHA UM NÚMERO",
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = Color.FromArgb(20, 30, 80),
                AutoSize = false, Size = new Size(400, 28),
                Location = new Point(40, 240), TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.Transparent
            };
            pnlJogo.Controls.Add(lblNumTit);

            Button[] btnsNum = new Button[5];
            int startX = 40;
            for (int i = 0; i < 5; i++)
            {
                int num = i + 1;
                var btn = new Button
                {
                    Text = num.ToString(),
                    Font = new Font("Segoe UI Black", 14f, FontStyle.Bold),
                    ForeColor = Color.FromArgb(20, 30, 80),
                    Size = new Size(64, 64),
                    Location = new Point(startX + i * 74, 278),
                    FlatStyle = FlatStyle.Flat,
                    BackColor = Color.White,
                    Cursor = Cursors.Hand,
                    Tag = num
                };
                btn.FlatAppearance.BorderColor = Color.FromArgb(180, 190, 220);
                btn.FlatAppearance.BorderSize = 2;
                btn.Region = new Region(RoundRect(btn.ClientRectangle, 32));
                btn.Click += (s, e) => SelecionarNumero((Button)s, btnsNum, btn);
                pnlJogo.Controls.Add(btn);
                btnsNum[i] = btn;
            }

            // ── Botão Jogar ─────────────────────────────────────────
            var btnJogar = CriarBotao("JOGAR!", Color.FromArgb(34, 160, 74), 180, 52);
            btnJogar.Font = new Font("Segoe UI Black", 13f, FontStyle.Bold);
            btnJogar.Location = new Point(150, 380);
            btnJogar.Click += (s, e) => Jogar(btnPar, btnImpar, btnsNum);
            pnlJogo.Controls.Add(btnJogar);
        }

        private Button[] _btnsParImpar;
        private void SelecionarParImpar(string escolha, Button btnPar, Button btnImpar)
        {
            escolhaJogador = escolha;
            btnPar.BackColor = escolha == "PAR" ? Color.FromArgb(0, 70, 180) : Color.FromArgb(0, 100, 220);
            btnImpar.BackColor = escolha == "IMPAR" ? Color.FromArgb(180, 70, 0) : Color.FromArgb(230, 100, 0);
            btnPar.FlatAppearance.BorderColor = escolha == "PAR" ? Color.White : Color.Transparent;
            btnImpar.FlatAppearance.BorderColor = escolha == "IMPAR" ? Color.White : Color.Transparent;
        }

        private void SelecionarNumero(Button btnClicado, Button[] todos, Button _ignore)
        {
            numeroJogador = (int)btnClicado.Tag;
            foreach (var b in todos)
            {
                bool sel = (int)b.Tag == numeroJogador;
                b.BackColor = sel ? Color.FromArgb(20, 30, 80) : Color.White;
                b.ForeColor = sel ? Color.White : Color.FromArgb(20, 30, 80);
            }
        }

        private void Jogar(Button btnPar, Button btnImpar, Button[] btnsNum)
        {
            if (string.IsNullOrEmpty(escolhaJogador))
            { MessageBox.Show("Escolha PAR ou ÍMPAR!", "Aviso"); return; }
            if (numeroJogador == 0)
            { MessageBox.Show("Escolha um número!", "Aviso"); return; }

            int numComp = rnd.Next(1, 6);
            int soma = numeroJogador + numComp;
            bool somaEPar = soma % 2 == 0;
            bool jogadorVenceu = (somaEPar && escolhaJogador == "PAR") || (!somaEPar && escolhaJogador == "IMPAR");
            bool empate = false;

            string resultado;
            if (jogadorVenceu) { pontoJogador++; resultado = "JOGADOR"; }
            else if (!jogadorVenceu) { pontoComputador++; resultado = "COMPUTADOR"; }
            else { empates++; resultado = "EMPATE"; empate = true; }

            // Verifica se houve empate real (soma par e jogador escolheu ímpar, etc – já coberto acima)
            // empate nunca ocorre nessa lógica; mantemos estrutura para futura extensão

            historico.Add(new HistoricoRodada
            {
                Rodada = historico.Count + 1,
                NumJogador = numeroJogador,
                NumComp = numComp,
                Soma = soma,
                EscolhaJogador = escolhaJogador,
                Resultado = resultado
            });

            lblPlacarJogador.Text = pontoJogador.ToString();
            lblPlacarEmpate.Text = empates.ToString();
            lblPlacarComp.Text = pontoComputador.ToString();

            // Preencher tela resultado
            PreencherResultado(resultado, soma, numComp);

            // Resetar seleção
            escolhaJogador = "";
            numeroJogador = 0;
            SelecionarParImpar("", btnPar, btnImpar);
            btnPar.BackColor = Color.FromArgb(0, 100, 220);
            btnImpar.BackColor = Color.FromArgb(230, 100, 0);
            foreach (var b in btnsNum) { b.BackColor = Color.White; b.ForeColor = Color.FromArgb(20, 30, 80); }

            MostrarTela(pnlResultado);
        }

        // ════════════════════════════════════════════════════════════
        //  TELA 3 – RESULTADO DA RODADA
        // ════════════════════════════════════════════════════════════
        private void CriarTelaResultado()
        {
            pnlResultado = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(20, 30, 80), Visible = false };
            this.Controls.Add(pnlResultado);

            // Título
            var lblTit = new Label
            {
                Text = "RESULTADO DA RODADA",
                Font = new Font("Segoe UI Black", 14f, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = false, Size = new Size(460, 36),
                Location = new Point(10, 18), TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.Transparent
            };
            pnlResultado.Controls.Add(lblTit);

            // Placar mini
            var pnlPMini = new Panel { Size = new Size(420, 55), Location = new Point(30, 60), BackColor = Color.Transparent };
            pnlResultado.Controls.Add(pnlPMini);

            string[] tits2 = { "JOGADOR", "EMPATES", "COMPUTADOR" };
            Color[] cors2 = { Color.FromArgb(0, 100, 220), Color.FromArgb(80, 80, 80), Color.FromArgb(230, 100, 0) };
            Label[] lbs2 = new Label[3];
            int[] xs2 = { 0, 155, 310 };
            for (int i = 0; i < 3; i++)
            {
                var pC = new Panel { Size = new Size(110, 52), Location = new Point(xs2[i], 0), BackColor = cors2[i] };
                ArredondarPanel(pC, 10);
                pnlPMini.Controls.Add(pC);
                new Label { Text = tits2[i], Font = new Font("Segoe UI", 7f, FontStyle.Bold), ForeColor = Color.White, AutoSize = false, Size = new Size(110, 16), Location = new Point(0, 4), TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.Transparent }.Let(l => pC.Controls.Add(l));
                var lNum = new Label { Text = "0", Font = new Font("Segoe UI Black", 18f, FontStyle.Bold), ForeColor = Color.White, AutoSize = false, Size = new Size(110, 28), Location = new Point(0, 20), TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.Transparent };
                pC.Controls.Add(lNum);
                lbs2[i] = lNum;
            }
            lblResJogador = lbs2[0]; lblResEmpate = lbs2[1]; lblResComp = lbs2[2];

            // ── Área central (3 colunas: jogador | troféu/resultado | computador) ──
            int y0 = 130;

            // Coluna Jogador
            var lblVCE = new Label { Text = "VOCÊ ESCOLHEU", Font = new Font("Segoe UI", 8f, FontStyle.Bold), ForeColor = Color.FromArgb(160, 180, 220), AutoSize = false, Size = new Size(140, 20), Location = new Point(10, y0), TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.Transparent };
            pnlResultado.Controls.Add(lblVCE);

            picResJogador = new PictureBox { Size = new Size(80, 70), Location = new Point(40, y0 + 26), SizeMode = PictureBoxSizeMode.Zoom, BackColor = Color.Transparent };
            pnlResultado.Controls.Add(picResJogador);

            lblResEscolhaJogador = new Label { Text = "PAR", Font = new Font("Segoe UI Black", 11f, FontStyle.Bold), ForeColor = Color.FromArgb(0, 160, 255), AutoSize = false, Size = new Size(120, 28), Location = new Point(20, y0 + 100), TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.Transparent };
            pnlResultado.Controls.Add(lblResEscolhaJogador);

            new Label { Text = "NÚMERO", Font = new Font("Segoe UI", 8f), ForeColor = Color.FromArgb(160, 180, 220), AutoSize = false, Size = new Size(120, 18), Location = new Point(20, y0 + 128), TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.Transparent }.Let(l => pnlResultado.Controls.Add(l));

            lblResNumJogador = new Label { Text = "0", Font = new Font("Segoe UI Black", 22f, FontStyle.Bold), ForeColor = Color.White, AutoSize = false, Size = new Size(120, 36), Location = new Point(20, y0 + 146), TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.Transparent };
            pnlResultado.Controls.Add(lblResNumJogador);

            // Coluna Central
            picResTrofeu = new PictureBox { Size = new Size(80, 80), Location = new Point(200, y0 + 14), SizeMode = PictureBoxSizeMode.Zoom, BackColor = Color.Transparent };
            pnlResultado.Controls.Add(picResTrofeu);

            lblResMensagem = new Label { Text = "VOCÊ VENCEU!", Font = new Font("Segoe UI Black", 11f, FontStyle.Bold), ForeColor = Color.FromArgb(34, 200, 80), AutoSize = false, Size = new Size(160, 28), Location = new Point(160, y0 + 100), TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.Transparent };
            pnlResultado.Controls.Add(lblResMensagem);

            lblResSoma = new Label { Text = "SOMA: 0 + 0 = 0", Font = new Font("Segoe UI", 9f, FontStyle.Bold), ForeColor = Color.White, AutoSize = false, Size = new Size(160, 22), Location = new Point(160, y0 + 130), TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.Transparent };
            pnlResultado.Controls.Add(lblResSoma);

            // Coluna Computador
            new Label { Text = "COMPUTADOR", Font = new Font("Segoe UI", 8f, FontStyle.Bold), ForeColor = Color.FromArgb(160, 180, 220), AutoSize = false, Size = new Size(140, 20), Location = new Point(330, y0), TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.Transparent }.Let(l => pnlResultado.Controls.Add(l));

            picResComp = new PictureBox { Size = new Size(80, 70), Location = new Point(360, y0 + 26), SizeMode = PictureBoxSizeMode.Zoom, BackColor = Color.Transparent };
            pnlResultado.Controls.Add(picResComp);

            lblResEscolhaComp = new Label { Text = "PAR", Font = new Font("Segoe UI Black", 11f, FontStyle.Bold), ForeColor = Color.FromArgb(230, 100, 0), AutoSize = false, Size = new Size(120, 28), Location = new Point(340, y0 + 100), TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.Transparent };
            pnlResultado.Controls.Add(lblResEscolhaComp);

            new Label { Text = "NÚMERO", Font = new Font("Segoe UI", 8f), ForeColor = Color.FromArgb(160, 180, 220), AutoSize = false, Size = new Size(120, 18), Location = new Point(340, y0 + 128), TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.Transparent }.Let(l => pnlResultado.Controls.Add(l));

            lblResNumComp = new Label { Text = "0", Font = new Font("Segoe UI Black", 22f, FontStyle.Bold), ForeColor = Color.White, AutoSize = false, Size = new Size(120, 36), Location = new Point(340, y0 + 146), TextAlign = ContentAlignment.MiddleCenter, BackColor = Color.Transparent };
            pnlResultado.Controls.Add(lblResNumComp);

            // Botões
            var btnJogarNov = CriarBotao("🔄  JOGAR NOVAMENTE", Color.White, 200, 46);
            btnJogarNov.ForeColor = Color.FromArgb(20, 30, 80);
            btnJogarNov.Location = new Point(30, 470);
            btnJogarNov.Click += (s, e) =>
            {
                if (pontoJogador >= PONTOS_PARA_VENCER || pontoComputador >= PONTOS_PARA_VENCER)
                    MostrarTela(pnlFinal);
                else
                    MostrarTela(pnlJogo);
            };
            pnlResultado.Controls.Add(btnJogarNov);

            var btnVerHist = CriarBotao("📊  VER HISTÓRICO", Color.FromArgb(40, 55, 130), 200, 46);
            btnVerHist.Location = new Point(250, 470);
            btnVerHist.Click += (s, e) => { AtualizarHistorico(); MostrarTela(pnlHistorico); };
            pnlResultado.Controls.Add(btnVerHist);
        }

        private void PreencherResultado(string resultado, int soma, int numComp)
        {
            lblResJogador.Text = pontoJogador.ToString();
            lblResEmpate.Text = empates.ToString();
            lblResComp.Text = pontoComputador.ToString();

            var ult = historico[historico.Count - 1];
            lblResNumJogador.Text = ult.NumJogador.ToString();
            lblResNumComp.Text = numComp.ToString();
            lblResEscolhaJogador.Text = ult.EscolhaJogador;
            lblResSoma.Text = $"SOMA: {ult.NumJogador} + {numComp} = {soma}";

            // Ícones via emoji em pictureboxes
            SetEmojiPicture(picResJogador, ult.EscolhaJogador == "PAR" ? "🖐" : "✊");
            SetEmojiPicture(picResComp, soma % 2 == 0 ? "🖐" : "✊");

            string escolhaComp = soma % 2 == 0 ? "PAR" : "ÍMPAR";
            lblResEscolhaComp.Text = escolhaComp;

            if (resultado == "JOGADOR")
            {
                lblResMensagem.Text = "VOCÊ VENCEU!";
                lblResMensagem.ForeColor = Color.FromArgb(34, 200, 80);
                SetEmojiPicture(picResTrofeu, "🏆");
            }
            else
            {
                lblResMensagem.Text = "COMPUTADOR VENCEU!";
                lblResMensagem.ForeColor = Color.FromArgb(230, 100, 0);
                SetEmojiPicture(picResTrofeu, "🤖");
            }

            if (pontoJogador >= PONTOS_PARA_VENCER || pontoComputador >= PONTOS_PARA_VENCER)
                PreencherFinal(resultado);
        }

        // ════════════════════════════════════════════════════════════
        //  TELA 4 – HISTÓRICO
        // ════════════════════════════════════════════════════════════
        private DataGridView dgvHistorico;

        private void CriarTelaHistorico()
        {
            pnlHistorico = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(20, 30, 80), Visible = false };
            this.Controls.Add(pnlHistorico);

            var lblTit = new Label
            {
                Text = "📋  HISTÓRICO DAS RODADAS",
                Font = new Font("Segoe UI Black", 13f, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = false, Size = new Size(460, 40),
                Location = new Point(10, 20), TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.Transparent
            };
            pnlHistorico.Controls.Add(lblTit);

            dgvHistorico = new DataGridView
            {
                Size = new Size(420, 440),
                Location = new Point(30, 70),
                BackgroundColor = Color.FromArgb(30, 42, 100),
                BorderStyle = BorderStyle.None,
                GridColor = Color.FromArgb(50, 70, 150),
                RowHeadersVisible = false,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                Font = new Font("Segoe UI", 9f),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
                ColumnHeadersHeight = 32
            };
            dgvHistorico.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(10, 20, 60);
            dgvHistorico.ColumnHeadersDefaultCellStyle.ForeColor = Color.FromArgb(160, 180, 220);
            dgvHistorico.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            dgvHistorico.DefaultCellStyle.BackColor = Color.FromArgb(30, 42, 100);
            dgvHistorico.DefaultCellStyle.ForeColor = Color.White;
            dgvHistorico.DefaultCellStyle.SelectionBackColor = Color.FromArgb(50, 80, 160);
            dgvHistorico.DefaultCellStyle.SelectionForeColor = Color.White;
            dgvHistorico.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(20, 32, 90);

            dgvHistorico.Columns.Add("Rodada", "RODADA");
            dgvHistorico.Columns.Add("Voce", "VOCÊ");
            dgvHistorico.Columns.Add("Comp", "COMP.");
            dgvHistorico.Columns.Add("Soma", "SOMA");
            dgvHistorico.Columns.Add("Escolha", "ESCOLHA");
            dgvHistorico.Columns.Add("Resultado", "RESULTADO");
            dgvHistorico.CellFormatting += DgvHistorico_CellFormatting;

            pnlHistorico.Controls.Add(dgvHistorico);

            var btnVoltar = CriarBotao("◀  VOLTAR", Color.White, 180, 46);
            btnVoltar.ForeColor = Color.FromArgb(20, 30, 80);
            btnVoltar.Location = new Point(150, 530);
            btnVoltar.Click += (s, e) => MostrarTela(pnlResultado);
            pnlHistorico.Controls.Add(btnVoltar);
        }

        private void DgvHistorico_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dgvHistorico.Columns[e.ColumnIndex].Name == "Resultado" && e.Value != null)
            {
                if (e.Value.ToString().Contains("VOCÊ"))
                    e.CellStyle.ForeColor = Color.FromArgb(34, 200, 80);
                else if (e.Value.ToString().Contains("COMPUTADOR"))
                    e.CellStyle.ForeColor = Color.FromArgb(230, 100, 0);
            }
        }

        private void AtualizarHistorico()
        {
            dgvHistorico.Rows.Clear();
            foreach (var h in historico)
            {
                string res = h.Resultado == "JOGADOR" ? "VOCÊ VENCEU" : h.Resultado == "EMPATE" ? "EMPATE" : "COMPUTADOR VENCEU";
                dgvHistorico.Rows.Add(h.Rodada, h.NumJogador, h.NumComp, h.Soma, h.EscolhaJogador, res);
            }
        }

        // ════════════════════════════════════════════════════════════
        //  TELA 5 – FINAL DO JOGO
        // ════════════════════════════════════════════════════════════
        private void CriarTelaFinal()
        {
            pnlFinal = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(240, 244, 255), Visible = false };
            this.Controls.Add(pnlFinal);

            // Card
            var pnlCard = new Panel
            {
                Size = new Size(380, 260),
                Location = new Point(50, 150),
                BackColor = Color.White
            };
            ArredondarPanel(pnlCard, 20);
            pnlFinal.Controls.Add(pnlCard);

            picFinalIcone = new PictureBox { Size = new Size(90, 90), Location = new Point(145, 20), SizeMode = PictureBoxSizeMode.Zoom, BackColor = Color.Transparent };
            pnlCard.Controls.Add(picFinalIcone);

            lblFinalMensagem = new Label
            {
                Text = "PARABÉNS!\nVOCÊ VENCEU!",
                Font = new Font("Segoe UI Black", 18f, FontStyle.Bold),
                ForeColor = Color.FromArgb(34, 160, 74),
                AutoSize = false, Size = new Size(360, 70),
                Location = new Point(10, 120), TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.Transparent
            };
            pnlCard.Controls.Add(lblFinalMensagem);

            lblFinalPlacar = new Label
            {
                Text = "5 x 3",
                Font = new Font("Segoe UI Black", 28f, FontStyle.Bold),
                ForeColor = Color.FromArgb(20, 30, 80),
                AutoSize = false, Size = new Size(360, 50),
                Location = new Point(10, 190), TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.Transparent
            };
            pnlCard.Controls.Add(lblFinalPlacar);

            var btnNovoJogo = CriarBotao("▶  NOVO JOGO", Color.FromArgb(34, 160, 74), 200, 52);
            btnNovoJogo.Font = new Font("Segoe UI Black", 13f, FontStyle.Bold);
            btnNovoJogo.Location = new Point(140, 440);
            btnNovoJogo.Click += (s, e) => NovoJogo();
            pnlFinal.Controls.Add(btnNovoJogo);
        }

        private void PreencherFinal(string vencedor)
        {
            if (vencedor == "JOGADOR")
            {
                lblFinalMensagem.Text = "PARABÉNS!\nVOCÊ VENCEU!";
                lblFinalMensagem.ForeColor = Color.FromArgb(34, 160, 74);
                SetEmojiPicture(picFinalIcone, "🏆");
            }
            else
            {
                lblFinalMensagem.Text = "FIM DE JOGO!\nCOMPUTADOR VENCEU!";
                lblFinalMensagem.ForeColor = Color.FromArgb(230, 100, 0);
                SetEmojiPicture(picFinalIcone, "🤖");
            }
            lblFinalPlacar.Text = $"{pontoJogador} x {pontoComputador}";
        }

        private void NovoJogo()
        {
            pontoJogador = 0; pontoComputador = 0; empates = 0;
            historico.Clear();
            lblPlacarJogador.Text = "0"; lblPlacarEmpate.Text = "0"; lblPlacarComp.Text = "0";
            MostrarTela(pnlJogo);
        }

        // ════════════════════════════════════════════════════════════
        //  UTILITÁRIOS
        // ════════════════════════════════════════════════════════════
        private void MostrarTela(Panel tela)
        {
            foreach (Panel p in new[] { pnlInicio, pnlJogo, pnlResultado, pnlHistorico, pnlFinal })
                p.Visible = false;
            tela.Visible = true;
            tela.BringToFront();
        }

        private Button CriarBotao(string texto, Color cor, int w, int h)
        {
            var btn = new Button
            {
                Text = texto,
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = cor,
                Size = new Size(w, h),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.Region = new Region(RoundRect(btn.ClientRectangle, 12));
            btn.Resize += (s, e) => btn.Region = new Region(RoundRect(btn.ClientRectangle, 12));
            return btn;
        }

        private GraphicsPath RoundRect(Rectangle r, int radius)
        {
            var path = new GraphicsPath();
            int d = radius * 2;
            path.AddArc(r.X, r.Y, d, d, 180, 90);
            path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        private void ArredondarPanel(Panel p, int radius)
        {
            p.Region = new Region(RoundRect(p.ClientRectangle, radius));
            p.Resize += (s, e) => p.Region = new Region(RoundRect(p.ClientRectangle, radius));
        }

        private void SetEmojiPicture(PictureBox pb, string emoji)
        {
            var bmp = new Bitmap(pb.Width, pb.Height);
            using var g = Graphics.FromImage(bmp);
            g.Clear(Color.Transparent);
            using var f = new Font("Segoe UI Emoji", pb.Height * 0.55f);
            var sz = g.MeasureString(emoji, f);
            g.DrawString(emoji, f, Brushes.White, (bmp.Width - sz.Width) / 2f, (bmp.Height - sz.Height) / 2f);
            pb.Image = bmp;
        }
    }

    // ── Extensão auxiliar (fluent) ──
    static class Extensions
    {
        public static T Let<T>(this T obj, Action<T> action) { action(obj); return obj; }
    }

    // ── Model ──
    class HistoricoRodada
    {
        public int Rodada { get; set; }
        public int NumJogador { get; set; }
        public int NumComp { get; set; }
        public int Soma { get; set; }
        public string EscolhaJogador { get; set; }
        public string Resultado { get; set; }
    }
}
