# 🎮 Par ou Ímpar – Windows Forms (Visual Studio 2022)

## Como abrir no Visual Studio 2022

1. Abra o **Visual Studio 2022**
2. Clique em **"Abrir um projeto ou solução"**
3. Navegue até a pasta e selecione **`ParOuImpar.sln`**
4. Pressione **F5** para compilar e executar

## Requisitos
- Visual Studio 2022
- .NET 8 SDK (Windows)
- Workload **"Desenvolvimento para desktop .NET"** instalada

## Estrutura dos arquivos
```
ParOuImpar.sln
ParOuImpar/
  ├── ParOuImpar.csproj
  ├── Program.cs
  ├── Form1.cs          ← toda a lógica e UI do jogo
  └── Form1.Designer.cs
```

## Telas do jogo
| Tela | Descrição |
|------|-----------|
| **Início** | Banner "Par ou Ímpar", botão Iniciar, regras |
| **Jogo** | Placar, escolha PAR/ÍMPAR, escolha de número (1–5) |
| **Resultado da rodada** | Quem ganhou, soma dos números, histórico |
| **Histórico** | Tabela com todas as rodadas |
| **Final** | Placar final, botão Novo Jogo |

## Regras
- Você escolhe **Par** ou **Ímpar** e um número de 1 a 5
- O computador escolhe um número de 1 a 5 aleatoriamente
- Os números são somados
- Se a soma bater com sua escolha, **você vence** a rodada
- Quem chegar a **5 pontos** primeiro vence o jogo!
