import os
import sys
from PySide6.QtCore import QEvent, Qt, QUrl
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QMainWindow,
    QStyle,
)

from interface_ui import Ui_MainWindow

class HorizonPlayer(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        
        
        
        self.ui.btn_excluir.hide()
        self.ui.lista_musicas.setSelectionMode(
            self.ui.lista_musicas.SelectionMode.ExtendedSelection
        )
        self.ui.lista_musicas.installEventFilter(self)

        
        self.setWindowTitle("🎵 Horizon Media Player")
        self.playlist = []
        self.indice_atual = -1
        self.player = QMediaPlayer(self)
        self.audio_output = QAudioOutput(self)
        self.player.setAudioOutput(self.audio_output)
        self.audio_output.setVolume(0.5)
        self._configurar_icones()
        self._conectar_sinais()

    
if __name__ == "__main__":

    
    
    
    
    app = QApplication(sys.argv)

    
    if os.path.exists("style.qss"):

        
        with open("style.qss", "r", encoding="utf-8") as f:

            
            app.setStyleSheet(f.read())

    
    
    
    janela = HorizonPlayer()

    
    janela.show()

    
    
    
    
    
    
    
    sys.exit(app.exec())
